'''
WPA APP
'''
from flask import Flask, request, render_template
from flask_cors import CORS
import pickle
import pandas as pd
import matplotlib.pyplot as plt
import shap
import os
from dotenv import load_dotenv
from langchain.chat_models import AzureChatOpenAI
from langchain.schema import HumanMessage, SystemMessage, ChatMessage, AIMessage
from PIL import Image, ImageDraw
import re


shap.initjs()
BASE_PATH = r"C:\\Users\frank\OneDrive - Oklahoma A and M System\WPA\Analysis\Frankle\data_tool_demo\\"

########################################################################
# load model here
load_dotenv()

open_ai_chat_model = AzureChatOpenAI(
    openai_api_base=os.environ['OPENAI_API_ENDPOINT'],
    openai_api_version="2023-05-15",
    deployment_name='gpt-35-16k-context',
    openai_api_key=os.environ['OPENAI_API_KEY'],
    openai_api_type="azure",
)

df_layout = pd.DataFrame({
    'entity': [],
    'message':[]
})
df_layout.to_csv('../UI-WPA - V2/static/df_layout.csv', index=False)

df_layout = pd.DataFrame({
    'entity': [],
    'message':[]
})
df_layout.to_csv('../UI-WPA - V2/static/df_tech.csv', index=False)

df_layout = pd.DataFrame({
    'entity': [],
    'message':[]
})
df_layout.to_csv('../UI-WPA - V2/static/df_general.csv', index=False)

########################################################################

app = Flask(__name__)
CORS(app)

@app.route('/')
def home():
    '''
    home controller
    '''
    return render_template('html/home.html')


@app.route('/clear_history_data', methods=['POST'])
def clear_history_data():
    df_layout = pd.DataFrame({
        'entity': [],
        'message':[]
    })
    df_layout.to_csv('../UI-WPA - V2/static/df_layout.csv', index=False)

    df_layout = pd.DataFrame({
        'entity': [],
        'message':[]
    })
    df_layout.to_csv('../UI-WPA - V2/static/df_tech.csv', index=False)

    df_layout = pd.DataFrame({
        'entity': [],
        'message':[]
    })
    df_layout.to_csv('../UI-WPA - V2/static/df_general.csv', index=False)
    
    return {
        'message': 'History data cleared'
    }


@app.route('/ai_helper', methods=['POST'])
def get_ai_response():
    '''
    handle input selected and inference here
    '''
    if request.method == 'POST':
        request_data = request.get_json()

    user_query = request_data['search_query']

    df_office_info = pd.read_csv('static/df_office_info.csv')
    df_meeting_rooms = pd.read_csv('static/df_office_info_meeting.csv')

    if request_data['category'] == 'layout':
        df_history, system_message = layout()
        csv_file = 'static/df_layout.csv'


    if request_data['category'] == 'tech':
        df_history, system_message = tech()
        csv_file = 'static/df_tech.csv'

    if request_data['category'] == 'guide':
        df_history, system_message = guide()
        csv_file = 'static/df_general.csv'

    message_list = [
        SystemMessage(content=system_message)
    ]

    for _, row in df_history.sort_index().iterrows():
        if row['entity'] == 'user':
            message_list.append(
                HumanMessage(content=row['message'])
            )
        else:
            message_list.append(
                AIMessage(content=row['message'])
            )

    message_list.append(
        HumanMessage(content=user_query)
    )

    openai_response = open_ai_chat_model(messages=message_list)
    ai_response_text = openai_response.content

    df_history = pd.concat([
        df_history,
        pd.DataFrame({
            'entity': ['user', 'ai_copilot'],
            'message':[user_query, ai_response_text]
        })
    ], ignore_index=True)
    df_history.to_csv(csv_file, index=False)


    # add img for layout if possible
    img_response = ''
    img_response_2 = ''
    
    desk_number_match = list(set(re.findall(r'(Desk\s{0,1}\d{3})', ai_response_text)))
    desk_number = ""
    if len(desk_number_match) == 1:
        desk_number = desk_number_match[0]


    meeting_room_match = list(set(re.findall(r'(Meeting\s{1}Room\s{1}\d{1})', ai_response_text)))
    meeting_room = ""
    if len(meeting_room_match) == 1:
        meeting_room = meeting_room_match[0]


    try:
        if desk_number != "":
            df_coords = df_office_info[df_office_info['Desk Number'] == desk_number]
            x, y = df_coords['X Coordinate'].values[0], df_coords['Y Coordinate'].values[0]
            x = int(x)
            y = int(y)
            draw_x(image_path='static/office_layout.jpg', coordinates=(x, y), size=10, color=(255, 0, 0))
            draw_x(image_path='static/output_img.jpg', coordinates=(500, 150), size=10, color=(0, 0, 0)) # my desk location
            img_response = 'static/output_img.jpg'
    
        if meeting_room != "":
            meeting_df_coords = df_meeting_rooms[df_meeting_rooms['Meeting Rooms'] == meeting_room]
            x, y = meeting_df_coords['X Coordinate'].values[0], meeting_df_coords['Y Coordinate'].values[0]
            x = int(x)
            y = int(y)
            draw_x(image_path='static/SampleOfficeLayout.jpg', coordinates=(x, y), size=10, color=(255, 0, 0), op_img_path="static/meeeting_room_img.jpg")
            draw_x(image_path="static/meeeting_room_img.jpg", coordinates=(500, 150), size=10, color=(0, 0, 0), op_img_path="static/meeeting_room_img.jpg") # my desk location
            img_response_2 = "static/meeeting_room_img.jpg"
    except Exception as e:
        print(e)


    return {
        'ai_response': ai_response_text,
        'img_response': img_response,
        'img_response_2': img_response_2
    }





def layout():
    df_history = pd.read_csv('static/' + 'df_layout.csv')
    system_message = '''
        You are an AI Copilot that helps employee navigate through the company's office layout. This is simply a demo, so imagine a company with a large office space with multiple 
        desks and desk numbers assigned. Here is a table of the employee desks and their respective departments. Help answer the user query based on this information and imagine any additional information
        that might be required. REMEMBER TO CONSIDER THE PAST CHAT HISTORY PROVIDED BELOW.
        
        Give a detailed response and ask follow up questions to help them with any further related tasks. For example,
        
        User Query: Help me find where Johnson's desk is located.
        AI Response: Sure. There are two Johnsons in the company. One is in the Software Development department and the other is in the HR department. 
        Johnson from Software Development is at Desk 106 and Johnson from HR is at Desk 102. Do you want me to book a meeting with one of them?

        ---------------------------------------------------------------------------
        DESK LAYOUT, DEPARTMENT, CALENDAR SLOTS AND COORDINATES OF DESK: (X and Y Coordinates are for internal use only and not to be shared with the user.)

        If the employee does not exist, you can say "The employee does not exist in the company. Please check and try again."

        |    | Desk Number   | Employee Name   | Department   | Free Calendar Slots Today   |
        |---:|:--------------|:----------------|:-------------|:----------------------------|
        |  0 | Desk 101      | Me (The User)   | Marketing    | 8 am - 11 am; 2 pm - 5 pm   |
        |  1 | Desk 105      | Lisa            | Marketing    | 8 am - 9 am; 2 pm - 4 pm    |
        |  2 | Desk 110      | John            | Help Dept    | 11am - 1pm; 4pm - 5pm       |
        |  3 | Desk 108      | Smith           | Sales        | 10am - 1pm; 4pm - 6 pm      |
        |  4 | Desk 103      | Joe             | Sales        | 11am - 1pm; 4pm - 5pm       |
        |  5 | Desk 102      | Brad            | HR           | 8 am - 11 am; 3 pm - 5 pm   |
        |  6 | Desk 109      | Adam            | HR           | 8 am - 9 am; 2 pm - 4 pm    |
        |  7 | Desk 100      | Jack            | Software Dev | 11am - 1pm; 4pm - 5pm       |
        |  8 | Desk 106      | Johnson         | Software Dev | 8 am - 9 am; 2 pm - 4 pm    |
        |  9 | Desk 107      | Michael         | IT Dept      | 8 am - 11 am; 2 pm - 4 pm   |
        | 10 | Desk 111      | Scott           | IT Dept      | 9 am - 12 pm; 3 pm - 5 pm   |

        ---------------------------------------------------------------------------
        MEETING ROOMS AND THEIR CALENDAR SLOTS: (Do not show this table directly to the user. Summarize the information in the response. X and Y coordinates are for internal use only and not to be shared with the user.)
        |    | Meeting Rooms   | Room Size       | Availability   |
        |---:|:----------------|:----------------|:---------------|
        |  0 | Meeting Room 1  | LARGE           | 8 am - 2 pm    |
        |  1 | Meeting Room 2  | SMALL           | 10 am - 5 pm   |
    '''

    return df_history, system_message


def tech():
    df_history = pd.read_csv('static/' + 'df_tech.csv')
    system_message = '''
        You are an AI Copilot that helps employees resolve technical issues. This is simply a demo, so imagine a company with a large office space with multiple employees, 
        meeting rooms, and office equipments. 
        Considering this scenario, help answer the employee queries. 

        ALWAYS PROVIDE A STEP BY STEP SOLUTION THAT THE EMPLOYEES CAN FOLLOW. Format new lines using a <br> tag.

        ASK IF THEY NEED FURTHER ASSISTANCE OR IF THEY HAVE ANY OTHER RELATED QUERIES. OFFER TO CONNECT THEM TO THE IT DEPARTMENT IF REQUIRED.

        ---------------------------------------------------------------------------
        DESK LOCATION, AND FREE CALENDAR SLOTS TODAY FOR IT DEPARTMENT EMPLOYEES: (Do not show this table directly to the user. Summarize the information in the response.)

        |    | Desk Number   | Employee Name   | Department   | Free Calendar Slots Today   |
        |---:|:--------------|:----------------|:-------------|:----------------------------|
        |  0 | Desk 107      | Michael         | IT Dept      | 8 am - 11 am; 2 pm - 4 pm   |
        |  1 | Desk 111      | Scott           | IT Dept      | 9 am - 12 pm; 3 pm - 5 pm   |
    '''

    return df_history, system_message


def guide():
    df_history = pd.read_csv('static/' + 'df_general.csv')
    system_message = '''
        You are an AI Copilot that helps employees with general queries about the workplace. This is simply a demo, so imagine a company with a large office space with multiple employees having a recreational area,
        an app for ordering free lunches, a gym, a cafeteria with a generic coffee machine. 
        
        Considering this scenario, help answer the employee queries. 

        ALWAYS PROVIDE A STEP BY STEP SOLUTION THAT THE EMPLOYEES CAN FOLLOW. The employees might ask about anything regarding the general facilities in the workplace.

        ASK IF THEY NEED FURTHER ASSISTANCE OR IF THEY HAVE ANY OTHER RELATED QUERIES. OFFER TO CONNECT THEM TO THE "Help Department" IF REQUIRED.

        ---------------------------------------------------------------------------
        DESK LOCATION, AND FREE CALENDAR SLOTS TODAY FOR HELP DEPARTMENT EMPLOYEES: (Do not show this table directly to the user. Summarize the information in the response.)

        |    | Desk Number   | Employee Name   | Department   | Free Calendar Slots Today   |
        |---:|:--------------|:----------------|:-------------|:----------------------------|
        |  0 | Desk 110      | John            | Help Dept    | 11am - 1pm; 4pm - 5pm       |
    '''

    return df_history, system_message



def draw_x(image_path, coordinates, size=10, color=(255, 0, 0), op_img_path='static/output_img.jpg'):
    """
    Draw an X on an image at the specified coordinates.
    
    :param image_path: Path to the image file.
    :param coordinates: Tuple of (x, y) for the position of the center of the X.
    :param size: Size of the X.
    :param color: Color of the X, default is red.
    """
    # Load the image
    image = Image.open(image_path)
    draw = ImageDraw.Draw(image)

    # Coordinates for the X
    x, y = coordinates
    left_up = (x - size, y - size)
    right_down = (x + size, y + size)
    left_down = (x - size, y + size)
    right_up = (x + size, y - size)

    # Draw two lines to form an X
    draw.line([left_up, right_down], fill=color, width=7)
    draw.line([left_down, right_up], fill=color, width=7)

    # Save or display the image
    image.save(op_img_path)


